const DB_USER = "mern"
const DB_PASSWORD = "maley12345"
const DB_HOST = "maleydi.vak5s2q.mongodb.net"
const API_VERSION = "v1"
const IP_SERVER = "localhost"
const JWT_SECRET_KEY = "01200302002312121211C31FH3GF1N3CXF1D3G1H"

module.exports = {
    DB_USER,
    DB_PASSWORD,
    DB_HOST,
    API_VERSION,
    IP_SERVER,
    JWT_SECRET_KEY
}